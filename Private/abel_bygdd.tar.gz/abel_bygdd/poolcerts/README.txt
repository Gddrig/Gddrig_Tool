Please put pools' certs in this folder, named with pool host used in abelminer command, for example,
localhsot.cert.


