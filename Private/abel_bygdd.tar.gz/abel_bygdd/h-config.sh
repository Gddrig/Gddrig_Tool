####################################################################################
###
### Abel
###
### Hive integration: Gdd
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/custom ]] && . /hive/custom/abel_bygdd/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/abel_bygdd/h-manifest.conf

echo ""  > $CUSTOM_CONFIG_FILENAME
echo " -U -P stratums://535d0b460fe99035ec472b455ed54148e410a175654a4dd8dd23259a435c2c79:Sachaq37@pool-service-alicia.abelian.info:27778"  >> $CUSTOM_CONFIG_FILENAME
#echo "  disablePlot: false" >> $CUSTOM_CONFIG_FILENAME
#echo "  serverPort: 10088"  >> $CUSTOM_CONFIG_FILENAME 


