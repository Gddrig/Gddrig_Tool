#ifndef __HA__
#define __HA__

void heureActuelle();

#endif