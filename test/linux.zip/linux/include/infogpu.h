#ifndef __INFOGPU__
#define __INFOGPU__

void infoNvidia();

#endif