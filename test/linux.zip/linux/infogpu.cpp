#include <iostream>
//#include <Windows.h>
#include <stdio.h>
//#include <tchar.h>
#include <ctime>

//#include "include/nvml.h"
#include "include/hactuelle.h"

#ifdef USE_NVML
#include <nvml.h>
#define NVML_CALL( call )				\
{										\
	nvmlReturn_t nvmlError = call;		\
	if (NVML_SUCCESS != nvmlError )	{	\
		fprintf (stderr, "NVML_ERROR: %s (%d) in %d line of %s\n", nvmlErrorString( nvmlError ), nvmlError , __LINE__, __FILE__ ); \
	}									\
}
#else
#define NVML_CALL( call )
#endif

// Dynex colors
#ifdef WIN32
#define NC ""
#define RED ""
#define GRN ""
#define CYN ""
#define WH ""
#else
#define NC "\e[0m"
#define RED "\e[0;31m"
#define GRN "\033[1;32m"
#define CYN "\e[0;36m"
#define WH "\033[1;37m"
#endif

// The default path to the NVML DLL
//#define NVMLQUERY_DEFAULT_NVML_DLL_PATH _T("../nvml.dll")

/*// NVML Function pointer prototypes
typedef nvmlReturn_t (*PFNnvmlInit)(void);
typedef nvmlReturn_t (*PFNnvmlDeviceGetName)(nvmlDevice_t device, char* name, unsigned int length);
typedef nvmlReturn_t (*PFNnvmlDeviceGetHandleByIndex)(unsigned int index, nvmlDevice_t* device);
typedef nvmlReturn_t (*PFNnvmlDeviceGetCount)(unsigned int* deviceCount);
typedef nvmlReturn_t (*PFNnvmlDeviceGetTemperature)( nvmlDevice_t device, nvmlTemperatureSensors_t sensorType, unsigned int* temp );
typedef nvmlReturn_t (*PFNnvmlDeviceGetClockInfo)( nvmlDevice_t device, nvmlClockType_t type, unsigned int* clock );
typedef nvmlReturn_t (*PFNnvmlDeviceGetFanSpeed)( nvmlDevice_t device, unsigned int* speed );
typedef nvmlReturn_t (*PFNnvmlDeviceGetPowerUsage)( nvmlDevice_t device, unsigned int* power );

// NVML Function pointer instances
PFNnvmlInit pfn_nvmlInit = NULL ; 
PFNnvmlDeviceGetName pfn_nvmlDeviceGetName = NULL ;
PFNnvmlDeviceGetHandleByIndex pfn_nvmlDeviceGetHandleByIndex = NULL ;
PFNnvmlDeviceGetCount pfn_nvmlDeviceGetCount = NULL ;
PFNnvmlDeviceGetTemperature pfn_nvmlDeviceGetTemperature = NULL ;
PFNnvmlDeviceGetClockInfo pfn_nvmlDeviceGetClockInfo = NULL ;
PFNnvmlDeviceGetFanSpeed pfn_nvmlDeviceGetFanSpeed = NULL ;
PFNnvmlDeviceGetPowerUsage pfn_nvmlDeviceGetPowerUsage = NULL ;*/

void infoNvidia()
{
    /*time_t curr_time;
	curr_time = time(NULL);

	tm *tm_gmt = gmtime(&curr_time);*/

	//heureActuelle();
	
    std::cout << "	******************************************************" << std::endl;
	std::cout << "	*                                                    *" << std::endl;
	std::cout << "	*               Test Programme C++                   *" << std::endl;
	std::cout << "	*                   By Gddrig                        *" << std::endl;
	#ifdef WIN32
	std::cout << "	*                 Version Win32                      *" << std::endl;
	#else
	std::cout << "	*                 Version Linux                      *" << std::endl;
	#endif
	std::cout << "	*                                                    *" << std::endl;	
    std::cout << "	******************************************************" << std::endl;

   /* //int iRetValue = -1 ;
	nvmlInit();
	nvmlReturn_t nvRetValue;
    
    //HINSTANCE hDLLhandle = NULL ;
	//hDLLhandle = LoadLibrary(NVMLQUERY_DEFAULT_NVML_DLL_PATH) ;

if (NULL == hDLLhandle)
	{
		printf("NVML DLL is not installed or not found at the default path.\r\n") ;
		//return iRetValue ;
	}
else
    {
        heureActuelle();
        std::cout << GRN"  nvml.dll was found !\n" NC;
    }

// Get the function pointers from the DLL
pfn_nvmlInit = (PFNnvmlInit)GetProcAddress(hDLLhandle, "nvmlInit") ;
pfn_nvmlDeviceGetName = (PFNnvmlDeviceGetName)GetProcAddress(hDLLhandle, "nvmlDeviceGetName") ;
pfn_nvmlDeviceGetHandleByIndex = (PFNnvmlDeviceGetHandleByIndex)GetProcAddress(hDLLhandle, "nvmlDeviceGetHandleByIndex") ;
pfn_nvmlDeviceGetCount = (PFNnvmlDeviceGetCount)GetProcAddress(hDLLhandle, "nvmlDeviceGetCount") ;
pfn_nvmlDeviceGetTemperature =(PFNnvmlDeviceGetTemperature)GetProcAddress(hDLLhandle, "nvmlDeviceGetTemperature") ;
pfn_nvmlDeviceGetClockInfo =(PFNnvmlDeviceGetClockInfo)GetProcAddress(hDLLhandle, "nvmlDeviceGetClockInfo") ;
pfn_nvmlDeviceGetFanSpeed =(PFNnvmlDeviceGetFanSpeed)GetProcAddress(hDLLhandle, "nvmlDeviceGetFanSpeed") ;
pfn_nvmlDeviceGetPowerUsage =(PFNnvmlDeviceGetPowerUsage)GetProcAddress(hDLLhandle, "nvmlDeviceGetPowerUsage");*/


// Before any of the NVML functions can be used nvmlInit() must be called
	//nvRetValue = pfn_nvmlInit() ;

/*if (NVML_SUCCESS != nvRetValue)
	{
		// Can not call the NVML specific error string handler if the initialization failed
		printf ("[%s] error code :%d\r\n", "nvmlInit", nvRetValue) ;
		FreeLibrary(hDLLhandle) ;
		hDLLhandle = NULL ;
		//return iRetValue;
	}
else
    //printf ("nvmlInit() called successfully !\n") ;
	heureActuelle();
    std::cout << GRN"  nvmlInit() called successfully !\n" NC;*/

    // Get the number of GPUs
	unsigned int uiNumGPUs = 0 ;
	//nvRetValue = pfn_nvmlDeviceGetCount(&uiNumGPUs) ;
	//nvmlReturn_t nvRetValue =  nvmlDeviceGetCount_v2(&uiNumGPUs);

	heureActuelle();std::cout << "\n";
	heureActuelle();std::cout << "  +-------------------------------------------------------------------------------------------------------+ \n";
	heureActuelle();std::cout << "  | Device ID |            Name Board            | Core Temp | Core Clock | Mem Clock | Fan Speed | Power | \n";
	heureActuelle();std::cout << "  +-------------------------------------------------------------------------------------------------------+ \n";

   	for (unsigned int iDevIDX = 0; iDevIDX < uiNumGPUs; iDevIDX++)
	{

    /*// Get the GPU device handle
		nvmlDevice_t nvGPUDeviceHandle = NULL ;
		nvRetValue = pfn_nvmlDeviceGetHandleByIndex(iDevIDX, &nvGPUDeviceHandle) ;

    // Get the device name
		char cDevicename[NVML_DEVICE_NAME_BUFFER_SIZE];
		nvRetValue = pfn_nvmlDeviceGetName(nvGPUDeviceHandle,  cDevicename,  NVML_DEVICE_NAME_BUFFER_SIZE) ;

	// Get the device temperature
		unsigned int cDevicetemperature;
		nvRetValue = pfn_nvmlDeviceGetTemperature(nvGPUDeviceHandle, NVML_TEMPERATURE_GPU, &cDevicetemperature);

	// Get the device gpu clock core
		unsigned int cClockcore;
		nvRetValue = pfn_nvmlDeviceGetClockInfo(nvGPUDeviceHandle, NVML_CLOCK_GRAPHICS, &cClockcore);

	// Get the device gpu clock memory
		unsigned int cClockmemory;
		nvRetValue = pfn_nvmlDeviceGetClockInfo(nvGPUDeviceHandle, NVML_CLOCK_MEM, &cClockmemory);

	// Get the device fan speed
		unsigned int cFanspeed;
		nvRetValue = pfn_nvmlDeviceGetFanSpeed(nvGPUDeviceHandle, &cFanspeed);

	// Get the device power
		unsigned int cPower;
		nvRetValue = pfn_nvmlDeviceGetPowerUsage(nvGPUDeviceHandle, &cPower);
	
	    heureActuelle();std::cout << WH"  |    "  << iDevIDX << "      |  " GRN <<  cDevicename << WH"   |    " << cDevicetemperature << "C    |   " << cClockcore << "Mhz  |   " << cClockmemory <<  "Mhz |    " << cFanspeed << "%    |  " << cPower/1000 << "W  |\n";
		heureActuelle();std::cout << NC"  +-------------------------------------------------------------------------------------------------------+ \n" << std::endl;*/
    

    }


}