#include <iostream>


#include "include/infogpu.h"



int main(int argc, char* argv[])
{
	infoNvidia();

    int fin{};
    std::cout << "Press e then enter to exit \n";
    std::cin >> fin;
    return 0;
}