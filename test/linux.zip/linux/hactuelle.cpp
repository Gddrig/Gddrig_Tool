#include <iostream>
#include <ctime>
#include <cstdio>


void heureActuelle()
{
    time_t secondes;
    struct tm instant;

    time(&secondes);
    instant=*localtime(&secondes);

    int annee = instant.tm_year+1900;
    int mois = instant.tm_mon+1 ;
    int jours = instant.tm_mday;
    int heure = instant.tm_hour;
    int minute = instant.tm_min;
    int seconde = instant.tm_sec;
    //char buf[256];


    //std::sprintf(buf, "%s", mois );
    std::printf("[%.2i/%.2i/%.4i %.2i:%.2i:%.2i]", jours, mois, annee, heure, minute, seconde);

    

    //std::cout << jours << "/" << mois << "/" << annee << " " << heure << ":" << minute << ":" << seconde;
}